<?= $this->extend('templates/index'); ?>

<?= $this->section('content'); ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?= $this->include('templates/sidebar'); ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?= $this->include('templates/topbar'); ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Edit Profile</h1>

                    <div class="row">
                        <div class="col-lg">
                            <div class="card mb-3" style="max-width: 540px;">
                                <div class="row g-0">
                                    <div class="col-md-4">
                                        <img src="<?= base_url('/img/' . user()->user_image); ?>" class="img-fluid rounded-start mx-4 my-4" alt="<?= user()->username; ?>">
                                    </div>
                                    <div class="col-md-8">
                                        <div class="card-body">
                                            <h5 class="card-title">ID : <span class="badge badge-dark"><?= user()->username; ?></span></h5>
                                            <form action="<?= base_url('User/update/' . user()->id); ?>" method="POST" class="user">
                                                <?= csrf_field() ?>

                                                <input type="hidden" name="id" value="<?= user()->id; ?>">
                                                <?php if (user()->status === null && 2) :  ?>
                                                    <input type="hidden" name="status" value=2>
                                                <?php else : ?>
                                                    <input type="hidden" name="status" value=1>
                                                <?php endif; ?>

                                                <div class="mb-3">
                                                    <label for="judul" class="form-label">NIM</label>
                                                    <input type="text" class="form-control <?= ($validation->hasError('nim')) ? 'is-invalid' : ''; ?>" id="nim" name="nim" value="<?= (old('nim')) ? old('nim') : user()->nim; ?>" autofocus>
                                                    <div class="invalid-feedback">
                                                        <?= $validation->getError('nim'); ?>
                                                    </div>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="judul" class="form-label">Full Name</label>
                                                    <input type="text" class="form-control <?= ($validation->hasError('fullname')) ? 'is-invalid' : ''; ?>" id="fullname" name="fullname" value="<?= (old('fullname')) ? old('fullname') : user()->fullname; ?>">
                                                    <div class="invalid-feedback">
                                                        <?= $validation->getError('fullname'); ?>
                                                    </div>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="judul" class="form-label">E-mail</label>
                                                    <input type="email" class="form-control <?= ($validation->hasError('email')) ? 'is-invalid' : ''; ?>" id="email" name="email" value="<?= (old('email')) ? old('email') : user()->email; ?>">
                                                    <div class="invalid-feedback">
                                                        <?= $validation->getError('email'); ?>
                                                    </div>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="judul" class="form-label">Fakultas</label>
                                                    <input type="text" class="form-control <?= ($validation->hasError('fakultas')) ? 'is-invalid' : ''; ?>" id="fakultas" name="fakultas" value="<?= (old('fakultas')) ? old('fakultas') : user()->fakultas; ?>">
                                                    <div class="invalid-feedback">
                                                        <?= $validation->getError('fakultas'); ?>
                                                    </div>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="judul" class="form-label">Jurusan</label>
                                                    <input type="text" class="form-control <?= ($validation->hasError('jurusan')) ? 'is-invalid' : ''; ?>" id="jurusan" name="jurusan" value="<?= (old('jurusan')) ? old('jurusan') : user()->jurusan; ?>">
                                                    <div class="invalid-feedback">
                                                        <?= $validation->getError('jurusan'); ?>
                                                    </div>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="judul" class="form-label">Angkatan</label>
                                                    <input type="text" class="form-control <?= ($validation->hasError('angkatan')) ? 'is-invalid' : ''; ?>" id="angkatan" name="angkatan" value="<?= (old('angkatan')) ? old('angkatan') : user()->angkatan; ?>">
                                                    <div class="invalid-feedback">
                                                        <?= $validation->getError('angkatan'); ?>
                                                    </div>
                                                </div>
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Richzxx <?= date('Y'); ?></span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="<?= base_url('logout'); ?>">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <?= $this->endSection(); ?>