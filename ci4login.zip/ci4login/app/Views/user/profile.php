<?= $this->extend('templates/index'); ?>

<?= $this->section('content'); ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?= $this->include('templates/sidebar'); ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?= $this->include('templates/topbar'); ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">My Profile</h1>

                    <div class="row">
                        <div class="col-lg-8">
                            <div class="card mb-3" style="max-width: 540px;">
                                <div class="row g-0">
                                    <div class="col-md-4">
                                        <img src="<?= base_url('/img/' . user()->user_image); ?>" class="img-fluid rounded-start mx-2 my-2" alt="<?= user()->username; ?>">
                                    </div>
                                    <div class="col-md-8">
                                        <div class="card-body">
                                            <?php if (session()->getFlashdata('success')) : ?>
                                                <div class="alert alert-success mt-5 text-center" role="alert">
                                                    <?= session()->getFlashdata('success'); ?>
                                                </div>

                                            <?php endif; ?>

                                            <?php if (session()->getFlashdata('error')) : ?>
                                                <div class="alert alert-danger mt-5 text-center" role="alert">
                                                    <?= session()->getFlashdata('error'); ?>
                                                </div>

                                            <?php endif; ?>

                                            <h5 class="card-title">ID : <span class="badge badge-dark"><?= user()->username; ?></span></h5>
                                            <ul class="list-group list-group-flush">
                                                <?php if (user()->fullname) : ?>
                                                    <li class="list-group-item"><?= user()->fullname ?> <span class="badge badge-<?= ($user->name == 'admin') ? 'primary' : 'success'; ?>"><?= $user->name; ?></li>
                                                <?php else : ?>
                                                    <li class="list-group-item"><span class="badge badge-danger"><i class="fas fa-exclamation" style="font-size: 20px;"></i></span> Not Available <span class="badge badge-<?= ($user->name == 'admin') ? 'primary' : 'success'; ?>"><?= $user->name; ?></li>
                                                <?php endif; ?>

                                                <li class="list-group-item"><?= user()->email; ?></li>

                                                <?php if (user()->nim) : ?>
                                                    <li class="list-group-item">NIM : <?= user()->nim ?></li>
                                                <?php else : ?>
                                                    <li class="list-group-item"><span class="badge badge-danger"><i class="fas fa-exclamation" style="font-size: 20px;"></i></span> Not Available</li>
                                                <?php endif; ?>

                                                <?php if (user()->fakultas) : ?>
                                                    <li class="list-group-item">Fakultas : <?= user()->fakultas ?></li>
                                                <?php else : ?>
                                                    <li class="list-group-item"><span class="badge badge-danger"><i class="fas fa-exclamation" style="font-size: 20px;"></i></span> Not Available</li>
                                                <?php endif; ?>

                                                <?php if (user()->jurusan) : ?>
                                                    <li class="list-group-item">Jurusan : <?= user()->jurusan ?></li>
                                                <?php else : ?>
                                                    <li class="list-group-item"><span class="badge badge-danger"><i class="fas fa-exclamation" style="font-size: 20px;"></i></span> Not Available</li>
                                                <?php endif; ?>

                                                <?php if (user()->angkatan) : ?>
                                                    <li class="list-group-item">Angkatan : <?= user()->angkatan ?></li>
                                                <?php else : ?>
                                                    <li class="list-group-item"><span class="badge badge-danger"><i class="fas fa-exclamation" style="font-size: 20px;"></i></span> Not Available</li>
                                                <?php endif; ?>

                                                <?php if (user()->status == 1) : ?>
                                                    <li class="list-group-item">Status : <span class="badge badge-success">sudah Aktif</span></li>
                                                <?php else : ?>
                                                    <?php if (user()->status == 2) : ?>
                                                        <li class="list-group-item"> Akunmu sedang dalam proses Verifikasi <span class="badge badge-warning"><i class="far fa-check-circle" style="font-size: 20px;"></i></span> </li>
                                                    <?php else : ?>
                                                        <li class="list-group-item"><span class="badge badge-danger"><i class="fas fa-exclamation" style="font-size: 20px;"></i></span> Lengkapi Data Akunmu agar bisa mengaktifkan akun.</li>
                                                        <li class="list-group-item">Status : <span class="badge badge-danger">Belum Aktif</span></li>
                                                    <?php endif; ?>
                                                <?php endif; ?>

                                                <li class="list-group-item ms-auto">
                                                    <a href="<?= base_url('User/edit/' . user()->id) ?>" class="btn btn-sm btn-info">Edit Account</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Richzxx <?= date('Y'); ?></span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="<?= base_url('logout'); ?>">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <?= $this->endSection(); ?>