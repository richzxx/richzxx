<?php

namespace App\Controllers;

use App\Models\Model_mhs;

class Admin extends BaseController
{
    protected $config, $auth, $db, $builder, $model_Mhs;

    public function __construct()
    {
        $this->config = config('Auth');
        $this->auth = service('authentication');
        $this->db      = \Config\Database::connect();
        $this->builder = $this->db->table('users');
        $this->model_Mhs = new Model_mhs();
    }

    public function index()
    {

        $this->builder->select('users.id as userid, username, email, name, status');
        $this->builder->join('auth_groups_users', 'auth_groups_users.user_id = users.id');
        $this->builder->join('auth_groups', 'auth_groups.id = auth_groups_users.group_id');
        $query = $this->builder->get();

        $data = [
            'title' => 'User List',
            'config' => $this->config,
            'users' => $query->getResult()
        ];

        return view('admin/index', $data);
    }

    public function detail($id = 0)
    {

        $this->builder->select('users.id as userid, username, fullname, user_image, email, name, status');
        $this->builder->join('auth_groups_users', 'auth_groups_users.user_id = users.id');
        $this->builder->join('auth_groups', 'auth_groups.id = auth_groups_users.group_id');
        $this->builder->where('users.id', $id);
        $query = $this->builder->get();

        $data = [
            'title' => 'User List',
            'config' => $this->config,
            'user' => $query->getRow()
        ];

        if (empty($data['user'])) {
            return redirect()->to('Admin');
        }

        return view('admin/detail', $data);
    }

    public function delete($id = 0)
    {

        $this->builder->where('users.id', $id);
        $this->builder->delete();

        session()->setFlashData('success', 'Data Berhasil dihapus!');

        return redirect()->to('Admin');
    }

    public function edit($id = 0)
    {

        $this->builder->select(
            'users.id as userid, 
            username, 
            fullname, 
            user_image, 
            email, 
            name, 
            status,
            nim,
            fakultas,
            jurusan,
            angkatan'
        );
        $this->builder->join('auth_groups_users', 'auth_groups_users.user_id = users.id');
        $this->builder->join('auth_groups', 'auth_groups.id = auth_groups_users.group_id');
        $this->builder->where('users.id', $id);
        $query = $this->builder->get();

        $data = [
            'title' => 'My Profile',
            'validation' => \Config\Services::validation(),
            'config' => $this->config,
            'user' => $query->getRow(),
        ];

        if (empty($data['user'])) {
            return redirect()->to('User');
        }

        return view('Admin/edit', $data);
    }

    public function update($id)
    {
        $this->builder->select(
            'users.id as userid, 
            username, 
            fullname, 
            user_image, 
            email, 
            name,
            nim,
            fakultas,
            jurusan,
            angkatan'
        );
        $this->builder->join('auth_groups_users', 'auth_groups_users.user_id = users.id');
        $this->builder->join('auth_groups', 'auth_groups.id = auth_groups_users.group_id');
        $this->builder->where('users.id', $id);
        $query = $this->builder->get();

        $data = [
            'config' => $this->config,
            'user' => $query->getRow()
        ];

        //* Rule fullname
        if ($data['user']->fullname == $this->request->getVar('fullname')) {
            $rule_fullname = 'required';
        } else {
            $rule_fullname = 'required|is_unique[users.fullname]';
        }

        //* Rule email
        if ($data['user']->email == $this->request->getVar('email')) {
            $rule_email = 'required';
        } else {
            $rule_email = 'required|is_unique[users.email]';
        }

        //TODO Validasi
        if (!$this->validate([
            'email' =>
            [
                'rules' => $rule_email,
                'errors' => [
                    'required' => '{field} tidak boleh kosong',
                    'is_unique' => '{field} ini sudah terdaftar, Silahkan masukkan {field} yang berbeda'
                ]
            ],
            'nim' =>
            [
                'rules' => 'required|numeric',
                'errors' => [
                    'required' => '{field} tidak boleh kosong',
                    'numeric' => '{field} harus Nomor'
                ]
            ],
            'fullname' => [
                'rules' => $rule_fullname,
                'errors' => [
                    'required' => '{field} tidak boleh kosong'
                ]
            ],
            'fakultas' =>
            [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} tidak boleh kosong'
                ]
            ],
            'jurusan' =>
            [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} tidak boleh kosong'
                ]
            ],
            'angkatan' =>
            [
                'rules' => 'required|numeric|max_length[4]',
                'errors' => [
                    'required' => '{field} tidak boleh kosong',
                    'numeric' => '{field} harus berisi angka',
                    'max_length' => 'karaktek maksimal hanya 4'
                ]
            ]
        ])) {
            $validation = \Config\Services::validation();
            return redirect()->to('Admin/edit/' . $this->request->getVar('id'))->withInput()->with('validation', $validation);
        }

        $this->model_Mhs->save([
            'id' => $id,
            'email' => $this->request->getVar('email'),
            'nim' => $this->request->getVar('nim'),
            'fullname' => $this->request->getVar('fullname'),
            'fakultas' => $this->request->getVar('fakultas'),
            'jurusan' => $this->request->getVar('jurusan'),
            'angkatan' => $this->request->getVar('angkatan')
        ]);

        session()->setFlashData('success', 'Data Berhasil diubah!');

        return redirect()->to('Admin/' . $data['user']->userid);
    }

    public function active($id)
    {
        $this->builder->select(
            'users.id as userid,
            name, 
            status'
        );
        $this->builder->join('auth_groups_users', 'auth_groups_users.user_id = users.id');
        $this->builder->join('auth_groups', 'auth_groups.id = auth_groups_users.group_id');
        $this->builder->where('users.id', $id);
        $query = $this->builder->get();

        $data = [
            'config' => $this->config,
            'user' => $query->getRow()
        ];

        $this->model_Mhs->save([
            'id' => $id,
            'status' => $this->request->getVar('status')
        ]);

        session()->setFlashData('success', 'Data Berhasil diubah!');

        return redirect()->to('Admin/' . $data['user']->userid);
    }
}
