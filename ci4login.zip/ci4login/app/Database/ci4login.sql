-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2021 at 06:51 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ci4login`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_activation_attempts`
--

CREATE TABLE `auth_activation_attempts` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `token` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_activation_attempts`
--

INSERT INTO `auth_activation_attempts` (`id`, `ip_address`, `user_agent`, `token`, `created_at`) VALUES
(1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36 Edg/91.0.864.54', '29cb1519ce90f445b67a374b13b918dd', '2021-06-24 23:14:02'),
(2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36 Edg/91.0.864.54', '47067400dc790ee2ac6f5500667beb67', '2021-06-24 23:22:54'),
(3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36 Edg/91.0.864.54', '703c81b2977f231cda6f873a0c51ee65', '2021-06-24 23:26:28'),
(4, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36 Edg/91.0.864.54', '2688cceb01e249bfe9a8c2ea7acf3d80', '2021-06-24 23:50:20'),
(5, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36 Edg/91.0.864.54', '333ef4b6878f31d8f39d3cfe0f305371', '2021-06-25 23:28:22');

-- --------------------------------------------------------

--
-- Table structure for table `auth_groups`
--

CREATE TABLE `auth_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_groups`
--

INSERT INTO `auth_groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Site Administrator'),
(2, 'user', 'Regular User');

-- --------------------------------------------------------

--
-- Table structure for table `auth_groups_permissions`
--

CREATE TABLE `auth_groups_permissions` (
  `group_id` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `permission_id` int(11) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_groups_permissions`
--

INSERT INTO `auth_groups_permissions` (`group_id`, `permission_id`) VALUES
(1, 1),
(1, 2),
(2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `auth_groups_users`
--

CREATE TABLE `auth_groups_users` (
  `group_id` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `user_id` int(11) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_groups_users`
--

INSERT INTO `auth_groups_users` (`group_id`, `user_id`) VALUES
(1, 1),
(2, 6),
(2, 7),
(2, 8);

-- --------------------------------------------------------

--
-- Table structure for table `auth_logins`
--

CREATE TABLE `auth_logins` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `date` datetime NOT NULL,
  `success` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_logins`
--

INSERT INTO `auth_logins` (`id`, `ip_address`, `email`, `user_id`, `date`, `success`) VALUES
(1, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-24 23:00:10', 1),
(2, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-24 23:03:56', 1),
(3, '::1', 'richardlaurents04@gmail.com', 6, '2021-06-24 23:26:42', 1),
(4, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-24 23:29:16', 1),
(5, '::1', 'geraldchristian04@gmail.com', 7, '2021-06-24 23:50:29', 1),
(6, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 00:20:15', 1),
(7, '::1', 'richardlaurents04@gmail.com', 6, '2021-06-25 00:25:03', 1),
(8, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 00:31:55', 1),
(9, '::1', 'geraldchristian04@gmail.com', 7, '2021-06-25 00:32:07', 1),
(10, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 00:43:03', 1),
(11, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 03:12:18', 1),
(12, '::1', 'geraldchristian04@gmail.com', 7, '2021-06-25 03:48:13', 1),
(13, '::1', 'richardlaurents04@gmail.com', 6, '2021-06-25 03:50:23', 1),
(14, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 03:57:23', 1),
(15, '::1', 'richardlaurents04@gmail.com', 6, '2021-06-25 04:07:28', 1),
(16, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 04:22:47', 1),
(17, '::1', 'richardlaurents04@gmail.com', 6, '2021-06-25 04:28:03', 1),
(18, '::1', 'richardlaurents04@gmail.com', 6, '2021-06-25 04:38:03', 1),
(19, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 04:39:01', 1),
(20, '::1', 'richardlaurents04@gmail.com', 6, '2021-06-25 04:40:19', 1),
(21, '::1', 'richardlaurents04@gmail.com', 6, '2021-06-25 04:44:33', 1),
(22, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 04:52:46', 1),
(23, '::1', 'richardlaurents04@gmail.com', 6, '2021-06-25 05:20:28', 1),
(24, '::1', 'geraldchristian04@gmail.com', 7, '2021-06-25 05:21:31', 1),
(25, '::1', 'richardlaurents04@gmail.com', 6, '2021-06-25 08:07:07', 1),
(26, '::1', 'geraldchristian04@gmail.com', 7, '2021-06-25 08:09:24', 1),
(27, '::1', 'geraldchristian04@gmail.com', 7, '2021-06-25 08:22:11', 1),
(28, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 08:57:04', 1),
(29, '::1', 'geraldchristian04@gmail.com', 7, '2021-06-25 09:09:22', 1),
(30, '::1', 'richardlaurents04@gmail.com', 6, '2021-06-25 09:12:08', 1),
(31, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 09:22:13', 1),
(32, '::1', 'richardlaurents04@gmail.com', 6, '2021-06-25 09:30:11', 1),
(33, '::1', 'geraldchristian04@gmail.com', 7, '2021-06-25 09:41:46', 1),
(34, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 09:43:23', 1),
(35, '::1', 'richardlaurents04@gmail.com', 6, '2021-06-25 09:48:10', 1),
(36, '::1', 'geraldchristian04@gmail.com', 7, '2021-06-25 09:52:11', 1),
(37, '::1', 'richardlaurents04@gmail.com', 6, '2021-06-25 09:54:56', 1),
(38, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 09:55:18', 1),
(39, '::1', 'geraldchristian04@gmail.com', 7, '2021-06-25 10:00:45', 1),
(40, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 10:10:18', 1),
(41, '::1', 'geraldchristian04@gmail.com', 7, '2021-06-25 10:52:29', 1),
(42, '::1', 'richardlaurents04@gmail.com', 6, '2021-06-25 10:53:42', 1),
(43, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 11:43:02', 1),
(44, '::1', 'richardlaurents04@gmail.com', 6, '2021-06-25 12:08:09', 1),
(45, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 13:32:11', 1),
(46, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 21:00:22', 1),
(47, '::1', 'richardlaurents04@gmail.com', 6, '2021-06-25 21:06:23', 1),
(48, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 21:15:44', 1),
(49, '::1', 'geraldchristian04@gmail.com', 7, '2021-06-25 22:05:51', 1),
(50, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 22:09:40', 1),
(51, '::1', 'richardlaurents04@gmail.com', 6, '2021-06-25 22:28:40', 1),
(52, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 22:41:30', 1),
(53, '::1', 'richardlaurents04@gmail.com', 6, '2021-06-25 22:41:45', 1),
(54, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 22:48:57', 1),
(55, '::1', 'richardlaurents04@gmail.com', 6, '2021-06-25 22:49:24', 1),
(56, '::1', 'richzsam04@gmail.com', 8, '2021-06-25 23:28:58', 1),
(57, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 23:30:05', 1),
(58, '::1', 'richzsam04@gmail.com', 8, '2021-06-25 23:30:52', 1),
(59, '::1', 'ronaldorichard27@gmail.com', 1, '2021-06-25 23:39:35', 1);

-- --------------------------------------------------------

--
-- Table structure for table `auth_permissions`
--

CREATE TABLE `auth_permissions` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_permissions`
--

INSERT INTO `auth_permissions` (`id`, `name`, `description`) VALUES
(1, 'manage-users', 'Manage all User'),
(2, 'manage-profile', 'Manage user\'s profile');

-- --------------------------------------------------------

--
-- Table structure for table `auth_reset_attempts`
--

CREATE TABLE `auth_reset_attempts` (
  `id` int(11) UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `token` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `auth_tokens`
--

CREATE TABLE `auth_tokens` (
  `id` int(11) UNSIGNED NOT NULL,
  `selector` varchar(255) NOT NULL,
  `hashedValidator` varchar(255) NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `expires` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `auth_users_permissions`
--

CREATE TABLE `auth_users_permissions` (
  `user_id` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `permission_id` int(11) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(1, '2017-11-20-223112', 'Myth\\Auth\\Database\\Migrations\\CreateAuthTables', 'default', 'Myth\\Auth', 1624585963, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `nim` varchar(20) DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `fakultas` varchar(255) DEFAULT NULL,
  `jurusan` varchar(255) DEFAULT NULL,
  `angkatan` int(5) DEFAULT NULL,
  `user_image` varchar(255) NOT NULL DEFAULT 'default.svg',
  `password_hash` varchar(255) NOT NULL,
  `reset_hash` varchar(255) DEFAULT NULL,
  `reset_at` datetime DEFAULT NULL,
  `reset_expires` datetime DEFAULT NULL,
  `activate_hash` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `status_message` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `force_pass_reset` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `username`, `nim`, `fullname`, `fakultas`, `jurusan`, `angkatan`, `user_image`, `password_hash`, `reset_hash`, `reset_at`, `reset_expires`, `activate_hash`, `status`, `status_message`, `active`, `force_pass_reset`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'ronaldorichard27@gmail.com', 'richardlaurents', '173112706450179', 'Richard Laurent', 'FTKI', 'Informatika', 2017, 'default.svg', '$2y$10$cg/WJspOjN70nO0Ve5KQzu663qW7HRaoa5KGMZ.zzvdvSyBUXLVxK', NULL, NULL, NULL, '4fc78b0331cc4fccb0dddaed0eab2c1a', '1', NULL, 1, 0, '2021-06-24 22:59:06', '2021-06-24 22:59:06', NULL),
(6, 'richardlaurents04@gmail.com', 'richzxx', '173522224535311', 'Richard Laurent Samosir', 'FTKI', 'TI', 2017, 'default.svg', '$2y$10$80TvM4uImCaW0BK4QR8ileKgYDQqQs36gAOLlB9EApevRK054YaOO', NULL, NULL, NULL, NULL, '1', NULL, 1, 0, '2021-06-24 23:26:13', '2021-06-25 22:49:09', NULL),
(7, 'geraldchristian04@gmail.com', 'christge', '19208183984028', 'Christian Gerald', 'FTKI', 'Sistem Informasi', 2019, 'default.svg', '$2y$10$pgUggso7KPHVh/GXIQjX6Ow8Ovqr86ororygCN/WLco795TfrKIa2', NULL, NULL, NULL, NULL, '1', NULL, 1, 0, '2021-06-24 23:50:01', '2021-06-25 22:10:03', NULL),
(8, 'richzsam04@gmail.com', 'richzxx4', '17328393294235824', 'Richzxx', 'FTKI', 'TI', 2017, 'default.svg', '$2y$10$LNcigSS1nce9p4lX7lGYYeCNkoyrMf1TNYuz6ET.AnNZtTXpOe31a', NULL, NULL, NULL, NULL, '1', NULL, 1, 0, '2021-06-25 23:26:40', '2021-06-25 23:30:33', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_activation_attempts`
--
ALTER TABLE `auth_activation_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `auth_groups`
--
ALTER TABLE `auth_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `auth_groups_permissions`
--
ALTER TABLE `auth_groups_permissions`
  ADD KEY `auth_groups_permissions_permission_id_foreign` (`permission_id`),
  ADD KEY `group_id_permission_id` (`group_id`,`permission_id`);

--
-- Indexes for table `auth_groups_users`
--
ALTER TABLE `auth_groups_users`
  ADD KEY `auth_groups_users_user_id_foreign` (`user_id`),
  ADD KEY `group_id_user_id` (`group_id`,`user_id`);

--
-- Indexes for table `auth_logins`
--
ALTER TABLE `auth_logins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `auth_permissions`
--
ALTER TABLE `auth_permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `auth_reset_attempts`
--
ALTER TABLE `auth_reset_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `auth_tokens`
--
ALTER TABLE `auth_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `auth_tokens_user_id_foreign` (`user_id`),
  ADD KEY `selector` (`selector`);

--
-- Indexes for table `auth_users_permissions`
--
ALTER TABLE `auth_users_permissions`
  ADD KEY `auth_users_permissions_permission_id_foreign` (`permission_id`),
  ADD KEY `user_id_permission_id` (`user_id`,`permission_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_activation_attempts`
--
ALTER TABLE `auth_activation_attempts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `auth_groups`
--
ALTER TABLE `auth_groups`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `auth_logins`
--
ALTER TABLE `auth_logins`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `auth_permissions`
--
ALTER TABLE `auth_permissions`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `auth_reset_attempts`
--
ALTER TABLE `auth_reset_attempts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_tokens`
--
ALTER TABLE `auth_tokens`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_groups_permissions`
--
ALTER TABLE `auth_groups_permissions`
  ADD CONSTRAINT `auth_groups_permissions_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `auth_groups` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `auth_groups_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `auth_permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `auth_groups_users`
--
ALTER TABLE `auth_groups_users`
  ADD CONSTRAINT `auth_groups_users_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `auth_groups` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `auth_groups_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `auth_tokens`
--
ALTER TABLE `auth_tokens`
  ADD CONSTRAINT `auth_tokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `auth_users_permissions`
--
ALTER TABLE `auth_users_permissions`
  ADD CONSTRAINT `auth_users_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `auth_permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `auth_users_permissions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
